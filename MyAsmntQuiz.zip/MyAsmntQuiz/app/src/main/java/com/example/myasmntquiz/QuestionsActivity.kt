package com.example.myasmntquiz

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class QuestionsActivity : AppCompatActivity() {
    val userName = intent.getStringExtra("userName")
    val userCity = intent.getStringExtra("cityName")
    val userAge = intent.getStringExtra("age")
    var questionNumber = -1

    val question = findViewById<TextView>(R.id.question)
    val option_one = findViewById<TextView>(R.id.option_one)
    val option_two = findViewById<TextView>(R.id.option_two)
    val option_three = findViewById<TextView>(R.id.option_three)
    val option_four = findViewById<TextView>(R.id.option_four)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_questions)

    }
    fun setQuestion(){
       questionNumber++

    }
}