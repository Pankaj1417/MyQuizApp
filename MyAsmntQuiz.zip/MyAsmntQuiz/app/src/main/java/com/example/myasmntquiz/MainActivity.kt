package com.example.myasmntquiz

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        startQuizPressed()



    }
    fun startQuizPressed(){
        val startButton = findViewById<Button>(R.id.startButton)
        val userName = findViewById<EditText>(R.id.userName)
        val age = findViewById<EditText>(R.id.age)
        val cityName = findViewById<EditText>(R.id.cityName)
        startButton.setOnClickListener{
            if(userName.text.isEmpty()||age.text.isEmpty()||cityName.text.isEmpty()){
                Toast.makeText(this,"Name,Age and City are required Fields",
                        Toast.LENGTH_SHORT).show()
            }else{
                val intent = Intent(this,QuestionsActivity::class.java)
                intent.putExtra("userName",userName.text.toString())
                intent.putExtra("cityName",cityName.text.toString())
                intent.putExtra("date",age.text.toString())
                startActivity(intent)
                finish()
            }

        }
    }
}